using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyVersion("3.0.0.2157")]
[assembly: AssemblyFileVersion("3.0.0.2157")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Emgu Corporation")]
[assembly: AssemblyProduct("Emgu.CV")]
[assembly: AssemblyCopyright("Copyright Emgu Corporation 2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
